package report4.maze;

public class BFSPane 
{
	public static final int EAST = 0;
	public static final int SOUTH = 1;
	public static final int WEST = 2;
	public static final int NORTH = 3;
	public static final int ROWS = Maze.ROWS;
	public static final int COLS = Maze.COLS;


}
